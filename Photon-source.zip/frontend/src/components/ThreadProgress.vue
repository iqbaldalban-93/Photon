<script setup lang="ts">
import { computed } from 'vue'
import type { ThreadStatus } from '../upload/types'
import { Progress } from '@/components/ui/progress'

const props = defineProps<{
  thread: ThreadStatus
}>()

const statusConfig = computed(() => {
  switch (props.thread.Status) {
    case 'error':
      return { color: 'text-destructive', bg: 'bg-destructive/10', label: 'Error' }
    case 'completed':
      return { color: 'text-primary', bg: 'bg-primary/10', label: 'Done' }
    case 'skipped':
      return { color: 'text-warning', bg: 'bg-warning/12', label: 'Skipped' }
    case 'uploading':
      if (props.thread.Attempt > 1) {
        return { color: 'text-warning', bg: 'bg-warning/10', label: `Retry ${props.thread.Attempt - 1}` }
      }
      return { color: 'text-foreground', bg: 'bg-foreground/10', label: 'Uploading' }
    case 'hashing':
      return { color: 'text-muted-foreground', bg: 'bg-foreground/8', label: 'Hashing' }
    case 'checking':
      return { color: 'text-muted-foreground', bg: 'bg-foreground/8', label: 'Checking' }
    case 'finalizing':
      return { color: 'text-foreground', bg: 'bg-foreground/10', label: 'Finalizing' }
    default:
      return { color: 'text-muted-foreground', bg: 'bg-muted', label: props.thread.Status }
  }
})

const uploadPercent = computed(() => {
  if (props.thread.Status !== 'uploading' || !props.thread.BytesTotal) {
    return null
  }
  return Math.round((props.thread.BytesUploaded / props.thread.BytesTotal) * 100)
})

function formatBytes(bytes: number): string {
  if (bytes === 0) return '0 B'
  const k = 1024
  const sizes = ['B', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i]
}

const fileSizeDisplay = computed(() => {
  if (props.thread.Status !== 'uploading' || !props.thread.BytesTotal) {
    return null
  }
  return `${formatBytes(props.thread.BytesUploaded)}/${formatBytes(props.thread.BytesTotal)}`
})

const statusMessage = computed(() => props.thread.Message.replace(/^Error:\s*/, ''))
</script>

<template>
  <div class="px-2.5 py-2 bg-card border rounded-md">
    <div class="flex items-center gap-2 mb-1">
      <span
        :class="[
          'text-[10px] font-medium px-1.5 py-0.5 rounded',
          statusConfig.color,
          statusConfig.bg
        ]"
      >
        {{ statusConfig.label }}
      </span>
      <span
        v-if="thread.FileName"
        class="flex-1 text-xs truncate"
        :title="thread.FilePath"
      >
        {{ thread.FileName }}
      </span>
      <span
        v-else
        class="flex-1 text-xs truncate text-muted-foreground"
      >
        {{ thread.Message }}
      </span>
    </div>

    <template v-if="uploadPercent !== null">
      <Progress
        :model-value="uploadPercent"
        class="h-1 mb-1"
      />
      <div class="flex justify-between text-[10px] text-muted-foreground tabular-nums">
        <span>{{ fileSizeDisplay }}</span>
        <span>{{ uploadPercent }}%</span>
      </div>
    </template>
    <p
      v-else-if="thread.Status === 'error' || thread.Status === 'skipped'"
      :class="[
        'mt-1 text-[11px] leading-snug break-words',
        thread.Status === 'error' ? 'text-destructive' : 'text-muted-foreground'
      ]"
    >
      {{ statusMessage }}
    </p>
  </div>
</template>
